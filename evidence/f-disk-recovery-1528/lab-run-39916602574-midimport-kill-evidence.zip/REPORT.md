# Process kill during an active category import — interrupted-import recovery (F-DISK-RECOVERY-1 C1+C2) — run 20261023T071649Z

| artifact | reference |
|---|---|
| image under qualification | `culvert:ci-smoke` → `172.17.0.1:5056/culvert@sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd` |
| predecessor | `culvert:ci-smoke` → `172.17.0.1:5056/culvert@sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd` |
| bounded host | `docker:29-dind@sha256:7dcdfc4a20246236f558175182ccace1eb15a41bd3eb119dd2284f393498b7c1`, data root + containerd + stack + agent state on one 2048 MiB ext4 loop file (-m 0) |
| agent | shipped binary sha256 b35b38e8b82989328117138365310d195c10eff112f3714a5585b4a6068f825a, v1.0.269-candidate.g4524311ba974, privilege_mode=docker_group_lab, inside the bounded host |

| scenario | check | result | detail |
|---|---|---|---|
| E0 | bounded-fs | **PASS** | size=1992552KiB avail=1976120KiB image=/home/runner/work/_temp/killimport/attempt-1/appliance-root.img (sparse, cap 2048MiB) |
| E0 | image-content-cur | **PASS** | pushed 172.17.0.1:5056/culvert@sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd has config sha256:fc622ce09678a0c4df5291b8642262e09aca6faa8b4c5ae3d6e1db6ea2ecebd8 (re-hashed) = source tar config; tar sha256 eb9e1d40dfe0a0acb027f1ad775fbb |
| E0 | image-content-pred | **PASS** | pushed 172.17.0.1:5056/culvert@sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd has config sha256:fc622ce09678a0c4df5291b8642262e09aca6faa8b4c5ae3d6e1db6ea2ecebd8 (re-hashed) = source tar config; tar sha256 eb9e1d40dfe0a0acb027f1ad775fbb |
| E0 | image-store-bounded | **PASS** | server=29.8.2 driver=overlayfs root=/var/lib/docker containerd-store=[[driver-type io.containerd.snapshotter.v1]]; content store /var/lib/docker/containerd/daemon/io.containerd.content.v1.content; every state dir on one device (1792 ) |
| E0 | dind-image | **PASS** | docker:29-dind@sha256:7dcdfc4a20246236f558175182ccace1eb15a41bd3eb119dd2284f393498b7c1 = docker@sha256:7dcdfc4a20246236f558175182ccace1eb15a41bd3eb119dd2284f393498b7c1 |
| E0 | image-pulled | **PASS** | nested daemon runs sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd = the pushed manifest digest |
| E0 | seeded-predecessor | **PASS** | running v1.0.269-candidate.g4524311ba974 image=sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd state=1bbe43ac5db049dd |
| E0 | image-running | **PASS** | container culvert runs sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd |
| E0 | ca-identity | **PASS** | root CA sha256 CC:66:7C:85:B9:E2:3A:B0:F8:21:3A:A7:29:FF:D3:94:A6:12:31:82:62:81:0F:64:EB:22:C5:54:E3:E4:09:CB |
| E0 | enforcement | **PASS** | allowed=200 blocked=403 (default-deny + allow rule, real traffic through the proxy) |
| E0 | agent-identity | **PASS** | shipped binary sha256 b35b38e8b82989328117138365310d195c10eff112f3714a5585b4a6068f825a, v1.0.269-candidate.g4524311ba974 |
| E0 | agent-start | **PASS** | {"agent_version":"v1.0.269-candidate.g4524311ba974","status":"ok"} |
| K | pre-kill-history | **PASS** | config history digest 5b9128890b94b2d9 (2 version(s)) |
| K | custody-pre-run | **PASS** | inventory: nothing quarantined on the volume — nothing to hash or delete |
| K | import-pending-marker | **PASS** | C1: /data/catfeeddb.importing present and the import not yet certified — BeginImport wrote the durable intent BEFORE completing the bulk write; restarts=0 |
| K | interrupted-state | **PASS** | proxy SIGKILLed mid-import; /data/catfeeddb.importing still present and the import never certified — the stall's durable end-state, reached deterministically |
| K | recovered-serving | **PASS** | /health 200 version=v1.0.269-candidate.g4524311ba974 after one restart (compose up -d) |
| K | interrupted-import-quarantined | **PASS** | C2: the interrupted import was quarantined and the store rebuilt + available (quarantined_copies=1 quarantines_total=? available=1) — breaks the re-fault loop; health='no catfeeddb health line'; culvert_catfeeddb_available 1 culvert_catfeeddb_recovered 1 culve |
| K | marker-cleared | **PASS** | import-pending marker cleared after quarantine+rebuild (no false re-quarantine on later clean boots) |
| K | state-intact | **PASS** | admin login http 200; ui_users.json+ca.bundle digest 1bbe43ac5db049dd unchanged (Layer-1/admin/CA untouched by the Layer-2 recovery) |
| K | ca-identity-intact | **PASS** | root CA sha256 CC:66:7C:85:B9:E2:3A:B0:F8:21:3A:A7:29:FF:D3:94:A6:12:31:82:62:81:0F:64:EB:22:C5:54:E3:E4:09:CB |
| K | enforcement | **PASS** | allowed=200 blocked=403 (default-deny + allow rule, real traffic through the proxy) |
| K | restart-disk-full-degrades | **PASS** | the quarantined partial leaves too little room (write REFUSED (disk_space): 1029 MiB free, a 2601320-entry write needs about 1147 MiB; no community category data is loaded yet (admin-managed categories only)); the F-DISK guard REFUSED the re-sync and the node  |
| K | idempotent-no-reloop | **PASS** | a second clean restart did not re-quarantine (quarantined_copies stayed 1) — recovery is bounded, not a loop |
| K | custody-pre-free | **PASS** | inventoried BEFORE deletion: 1 entr(y/ies) [catfeeddb.corrupt.1792739843679578409], 6 files, 403701806 bytes; manifest sha256 31ff0061d1305dec96743d5798c497741ba0d176ea2f61cb493fe2cddbbe648b; 3 metadata file(s) retained (custody/pre-free/) |
| K | custody-matches-product | **PASS** | inventory holds 1 quarantined cop(y/ies) = culvert_catfeeddb_quarantined_copies 1 |
| K | delete-pre-free | **PASS** | deleted exactly the inventoried set [catfeeddb.corrupt.1792739843679578409] (manifest 31ff0061d1305dec96743d5798c497741ba0d176ea2f61cb493fe2cddbbe648b); none remain and nothing else appeared |
| K | free-space-recovery-converges | **PASS** | convergence PROVEN: sync complete: 2601320 domains in 7s (15s) — after freeing the quarantined partial, avail 1054052->1448308 KiB; feed: FeedSync: starting UT1 sync from https://raw.githubusercontent.com/NethServer/toulouse-bl-mirror/master/blacklists.tar.gz/ |
| K | post-convergence-state | **PASS** | admin login 200; ui_users.json+ca.bundle digest 1bbe43ac5db049dd = pre-kill |
| K | post-convergence-ca | **PASS** | root CA sha256 CC:66:7C:85:B9:E2:3A:B0:F8:21:3A:A7:29:FF:D3:94:A6:12:31:82:62:81:0F:64:EB:22:C5:54:E3:E4:09:CB = pre-kill |
| K | post-convergence-config-history | **PASS** | config version history digest 5b9128890b94b2d9 = pre-kill (2 version(s); API listing + on-disk files) |
| K | post-convergence-enforcement | **PASS** | allowed=200 blocked=403 (default-deny + allow rule, real traffic through the proxy) |
| K | post-convergence-layer2-durable | **PASS** | community store available=1, no import-pending marker |
| K | converged-store-serves | **FAIL** | a sync completed, but none of [pornhub.com xvideos.com xhamster.com redtube.com youporn.com] resolves to the community tier |
| K | clean-restart-after-convergence | **PASS** | restart from the converged state: no quarantine (recovered=0, quarantined_copies 0->0), no marker, no re-sync in 60s; log: quiet |
| K | converged-store-persists | **FAIL** | after the clean restart '' resolves 'not community' (before: 'none') |
| K | post-restart-state | **PASS** | admin login 200; ui_users.json+ca.bundle digest 1bbe43ac5db049dd = pre-kill |
| K | post-restart-ca | **PASS** | root CA sha256 CC:66:7C:85:B9:E2:3A:B0:F8:21:3A:A7:29:FF:D3:94:A6:12:31:82:62:81:0F:64:EB:22:C5:54:E3:E4:09:CB = pre-kill |
| K | post-restart-config-history | **PASS** | config version history digest 5b9128890b94b2d9 = pre-kill (2 version(s); API listing + on-disk files) |
| K | post-restart-enforcement | **PASS** | allowed=200 blocked=403 (default-deny + allow rule, real traffic through the proxy) |
| K | post-restart-layer2-durable | **PASS** | community store available=1, no import-pending marker |

Failures: 2
