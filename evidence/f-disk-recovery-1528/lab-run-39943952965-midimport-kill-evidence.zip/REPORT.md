# Process kill during an active category import — interrupted-import recovery (F-DISK-RECOVERY-1 C1+C2) — run 20261023T110946Z

| artifact | reference |
|---|---|
| image under qualification | `culvert:ci-smoke` → `172.17.0.1:5056/culvert@sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd` |
| predecessor | `culvert:ci-smoke` → `172.17.0.1:5056/culvert@sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd` |
| bounded host | `docker:29-dind@sha256:7dcdfc4a20246236f558175182ccace1eb15a41bd3eb119dd2284f393498b7c1`, data root + containerd + stack + agent state on one 2048 MiB ext4 loop file (-m 0) |
| agent | shipped binary sha256 b35b38e8b82989328117138365310d195c10eff112f3714a5585b4a6068f825a, v1.0.269-candidate.g4524311ba974, privilege_mode=docker_group_lab, inside the bounded host |

| scenario | check | result | detail |
|---|---|---|---|
| E0 | bounded-fs | **PASS** | size=1992552KiB avail=1976120KiB image=/home/runner/work/_temp/killimport/attempt-1/appliance-root.img (sparse, cap 2048MiB) |
| E0 | image-content-cur | **PASS** | pushed 172.17.0.1:5056/culvert@sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd has config sha256:fc622ce09678a0c4df5291b8642262e09aca6faa8b4c5ae3d6e1db6ea2ecebd8 (re-hashed) = source tar config; tar sha256 eb9e1d40dfe0a0acb027f1ad775fbb |
| E0 | image-content-pred | **PASS** | pushed 172.17.0.1:5056/culvert@sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd has config sha256:fc622ce09678a0c4df5291b8642262e09aca6faa8b4c5ae3d6e1db6ea2ecebd8 (re-hashed) = source tar config; tar sha256 eb9e1d40dfe0a0acb027f1ad775fbb |
| E0 | image-store-bounded | **PASS** | server=29.8.2 driver=overlayfs root=/var/lib/docker containerd-store=[[driver-type io.containerd.snapshotter.v1]]; content store /var/lib/docker/containerd/daemon/io.containerd.content.v1.content; every state dir on one device (1792 ) |
| E0 | dind-image | **PASS** | docker:29-dind@sha256:7dcdfc4a20246236f558175182ccace1eb15a41bd3eb119dd2284f393498b7c1 = docker@sha256:7dcdfc4a20246236f558175182ccace1eb15a41bd3eb119dd2284f393498b7c1 |
| E0 | image-pulled | **PASS** | nested daemon runs sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd = the pushed manifest digest |
| E0 | seeded-predecessor | **PASS** | running v1.0.269-candidate.g4524311ba974 image=sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd state=56e0e7bdd7b1005d |
| E0 | image-running | **PASS** | container culvert runs sha256:a89ba885b72af592504c5ddca3bf354b0946b0afe2b495001a50dc29feec19fd |
| E0 | ca-identity | **PASS** | root CA sha256 0D:C7:F5:42:C4:60:BC:3C:98:09:34:13:6D:DD:BF:53:AF:70:4A:5E:8F:48:CE:E6:66:C1:F0:08:84:EE:54:EC |
| E0 | enforcement | **PASS** | allowed=200 blocked=403 with the default-deny block page (real traffic through the proxy) |
| E0 | agent-identity | **PASS** | shipped binary sha256 b35b38e8b82989328117138365310d195c10eff112f3714a5585b4a6068f825a, v1.0.269-candidate.g4524311ba974 |
| E0 | agent-start | **PASS** | {"agent_version":"v1.0.269-candidate.g4524311ba974","status":"ok"} |
| K | pre-kill-history | **PASS** | config history digest 116195435b6fe877 (2 version(s)) |
| K | custody-pre-run | **PASS** | inventory (listing succeeded): nothing quarantined on the volume — nothing to preserve or delete |
| K | import-pending-marker | **PASS** | C1: /data/catfeeddb.importing present and the import not yet certified — BeginImport wrote the durable intent BEFORE completing the bulk write; restarts=0 |
| K | interrupted-state | **PASS** | proxy SIGKILLed mid-import; /data/catfeeddb.importing still present and the import never certified — the stall's durable end-state, reached deterministically |
| K | recovered-serving | **PASS** | /health 200 version=v1.0.269-candidate.g4524311ba974 after one restart (compose up -d) |
| K | interrupted-import-quarantined | **PASS** | C2: the interrupted import was quarantined and the store rebuilt + available (quarantined_copies=1 quarantines_total=? available=1) — breaks the re-fault loop; health='no catfeeddb health line'; culvert_catfeeddb_available 1 culvert_catfeeddb_recovered 1 culve |
| K | marker-cleared | **PASS** | import-pending marker cleared after quarantine+rebuild (no false re-quarantine on later clean boots) |
| K | state-intact | **PASS** | admin login http 200; ui_users.json+ca.bundle digest 56e0e7bdd7b1005d unchanged (Layer-1/admin/CA untouched by the Layer-2 recovery) |
| K | ca-identity-intact | **PASS** | root CA sha256 0D:C7:F5:42:C4:60:BC:3C:98:09:34:13:6D:DD:BF:53:AF:70:4A:5E:8F:48:CE:E6:66:C1:F0:08:84:EE:54:EC |
| K | enforcement | **PASS** | allowed=200 blocked=403 with the default-deny block page (real traffic through the proxy) |
| K | restart-disk-full-degrades | **PASS** | the quarantined partial leaves too little room (write REFUSED (disk_space): 1029 MiB free, a 2601320-entry write needs about 1147 MiB; no community category data is loaded yet (admin-managed categories only)); the F-DISK guard REFUSED the re-sync and the node  |
| K | idempotent-no-reloop | **PASS** | a second clean restart did not re-quarantine (quarantined_copies stayed 1) — recovery is bounded, not a loop |
| K | custody-pre-free | **PASS** | BEFORE deletion: 1 entr(y/ies) [catfeeddb.corrupt.1792753821739087458], 6 files, 403701806 bytes; manifest sha256 3e23a814300b8c67375d235dfb83c3a4901de203e33229812ee79e2a4feb33d0; complete bytes preserved off-volume as quarantine.tar.gz (sha256 1d6740c849a48a0 |
| K | custody-matches-product | **PASS** | inventory holds 1 quarantined cop(y/ies) = culvert_catfeeddb_quarantined_copies 1 |
| K | delete-pre-free | **PASS** | deleted exactly the inventoried, preserved set [catfeeddb.corrupt.1792753821739087458] (manifest 3e23a814300b8c67375d235dfb83c3a4901de203e33229812ee79e2a4feb33d0, re-hashed unchanged before deletion); verified gone by a successful listing; nothing else appeare |
| K | free-space-recovery-converges | **PASS** | convergence PROVEN: sync complete: 2601320 domains in 9s (15s) — after freeing the quarantined partial, avail 1054056->1448312 KiB; feed: FeedSync: starting UT1 sync from https://raw.githubusercontent.com/NethServer/toulouse-bl-mirror/master/blacklists.tar.gz/ |
| K | custody-post-free | **PASS** | inventory (listing succeeded): nothing quarantined on the volume — nothing to preserve or delete |
| K | post-convergence-state | **PASS** | admin login 200; ui_users.json+ca.bundle digest 56e0e7bdd7b1005d = pre-kill |
| K | post-convergence-ca | **PASS** | root CA sha256 0D:C7:F5:42:C4:60:BC:3C:98:09:34:13:6D:DD:BF:53:AF:70:4A:5E:8F:48:CE:E6:66:C1:F0:08:84:EE:54:EC = pre-kill |
| K | post-convergence-config-history | **PASS** | config version history digest 116195435b6fe877 = pre-kill (2 version(s); API listing + on-disk files) |
| K | post-convergence-enforcement | **PASS** | allowed=200 blocked=403 with the default-deny block page (real traffic through the proxy) |
| K | post-convergence-layer2-durable | **PASS** | community store available=1, no import-pending marker |
| K | converged-store-serves | **PASS** | /api/urlcat/lookup resolves 0-casino.info (taken from the downloaded feed) -> tier=community category='Gambling' — the converged import is what serves; raw responses in probes.txt |
| K | clean-restart-after-convergence | **PASS** | no quarantine (recovered=0, quarantined_copies 0->0), no marker, no re-sync in a log that was read (settle 60s; raw log clean-restart.log); log: quiet |
| K | converged-store-persists | **PASS** | after the clean restart 0-casino.info still resolves tier=community 'Gambling' — the certified store survived the restart |
| K | post-restart-state | **PASS** | admin login 200; ui_users.json+ca.bundle digest 56e0e7bdd7b1005d = pre-kill |
| K | post-restart-ca | **PASS** | root CA sha256 0D:C7:F5:42:C4:60:BC:3C:98:09:34:13:6D:DD:BF:53:AF:70:4A:5E:8F:48:CE:E6:66:C1:F0:08:84:EE:54:EC = pre-kill |
| K | post-restart-config-history | **PASS** | config version history digest 116195435b6fe877 = pre-kill (2 version(s); API listing + on-disk files) |
| K | post-restart-enforcement | **PASS** | allowed=200 blocked=403 with the default-deny block page (real traffic through the proxy) |
| K | post-restart-layer2-durable | **PASS** | community store available=1, no import-pending marker |
| K | custody-post-restart | **PASS** | inventory (listing succeeded): nothing quarantined on the volume — nothing to preserve or delete |
| midimport-kill | convergence-verdict | **PASS** | convergence PROVEN (FeedSync sync complete observed) — the mandatory convergence verdict is satisfied |

Failures: 0
