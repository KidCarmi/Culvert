# Appliance lab — guest boot qualification (run 20261026T141617Z)

| identity | value |
|---|---|
| lab/harness commit | `a2927d13296973143659ff84e09e8fa1cefc868a` |
| OVA | `culvert-appliance-1.0.327-candidate.gb910508629e9-ubuntu-24.04.ova` sha256 `61c46d6db6603d76edbb0d64327bed85e76bea86d24457e9f3ae36e71bd5854a` |
| appliance source (guest build-info) | `?` |
| application image in the guest | `?` |
| accelerator | kvm (preflight: `preflight.json`) |
| access | read-only `culvert-operator` SSH (imported key) + authenticated local console (`culvert`, PAM + sudo) |

| step | check | result | detail |
|---|---|---|---|
| P | tools | **PASS** | qemu, qemu-img, ssh, curl, python3, openssl, iso tool present |
| P | memory | **PASS** | 14512 MiB available (need 6144) |
| P | disk | **PASS** | 81 GiB free at //culvert-lab/lab (need 20: OVA + VMDK + base + overlay growth) |
| P | accel | **PASS** | accel=kvm (kvm usable: yes) |
| 1 | ova-sha256 | **PASS** | culvert-appliance-1.0.327-candidate.gb910508629e9-ubuntu-24.04.ova sha256 61c46d6db6603d76edbb0d64327bed85e76bea86d24457e9f3ae36e71bd5854a |
| 1 | ova-manifest | **PASS** | every .mf digest matches |
| 1 | engine-overlay | **FAIL** | not installed+held as expected: containerd.io=2.4.2-3~ubuntu.24.04~noble docker-ce-cli=5:29.9.2-1~ubuntu.24.04~noble docker-ce=5:29.9.2-1~ubuntu.24.04~noble  |
| C | guest-reachable | **INFO** | guest not reachable at collect time; console log only |

Totals: fail=1, info=1, pass=6

Not qualified by this lab: vSphere/ESXi import (ovftool), the guestinfo OVF transport, VMware Tools, LSI Logic SCSI, the hypervisor's tty1 console (ttyS0 here), datastore/thin-provisioning behaviour, the proxy's Release Management dispatch (6c calls the agent socket as its peer, with TEST-ONLY trust), and F-DISK-1 (owned by the bounded nested-Docker harness; still OPEN).
