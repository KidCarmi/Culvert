# Appliance lab — guest boot qualification (run 20261026T142325Z)

| identity | value |
|---|---|
| lab/harness commit | `40e284288bb586cd1aab50dfc57c74afbe1b4276` |
| OVA | `culvert-appliance-1.0.327-candidate.gb910508629e9-ubuntu-24.04.ova` sha256 `61c46d6db6603d76edbb0d64327bed85e76bea86d24457e9f3ae36e71bd5854a` |
| appliance source (guest build-info) | `b910508629e9d80352067bc8ec608753ddf0924e` |
| application image in the guest | `sha256:ca27cf9a645431ed77255efa0897daabb63bbed9c6b4acd6ac574820422d186c` |
| accelerator | kvm (preflight: `preflight.json`) |
| access | read-only `culvert-operator` SSH (imported key) + authenticated local console (`culvert`, PAM + sudo) |

| step | check | result | detail |
|---|---|---|---|
| P | tools | **PASS** | qemu, qemu-img, ssh, curl, python3, openssl, iso tool present |
| P | memory | **PASS** | 14698 MiB available (need 6144) |
| P | disk | **PASS** | 81 GiB free at //culvert-lab/lab (need 20: OVA + VMDK + base + overlay growth) |
| P | accel | **PASS** | accel=kvm (kvm usable: yes) |
| 1 | ova-sha256 | **PASS** | culvert-appliance-1.0.327-candidate.gb910508629e9-ubuntu-24.04.ova sha256 61c46d6db6603d76edbb0d64327bed85e76bea86d24457e9f3ae36e71bd5854a |
| 1 | ova-manifest | **PASS** | every .mf digest matches |
| 1 | engine-overlay | **PASS** | LAB-ONLY: containerd.io=2.4.2-3~ubuntu.24.04~noble docker-ce-cli=5:29.9.2-1~ubuntu.24.04~noble docker-ce=5:29.9.2-1~ubuntu.24.04~noble installed (dpkg ii/hi) + held in the disposable disk BEFORE first boot; DEB sha256s verified; the booted disk is NOT the OVA's disk |
| 1 | disk-chain | **PASS** | disk.raw (disposable copy of the OVA's own VMDK) → direct-I/O loop /dev/loop0 → dm culvert-lab-4bb99689 (linear; latency injectable); QEMU cache=none |
| 2 | boot-started | **PASS** | qemu pid 10402 accel=kvm |
| 2 | kernel-started | **PASS** | [    0.000000] Linux version 7.0.0-38-generic (buildd@lcy02-amd64-063) (x86_64-linux-gnu-g after 5s |
| 2 | operator-ssh-up | **PASS** | culvert-operator SSH (OVF-delivered key, status-json) after 23s |
| 2 | firstboot-complete | **PASS** | status-json: complete recorded, phase provisioned, 55s from power-on |
| 3 | operator-observe | **PASS** | culvert-operator: help, status, status-json (valid JSON, version 1.0.327-candidate.gb910508629e9), diagnostics |
| 3 | status-setup-pending | **PASS** | status-json setup_status=pending, phase=provisioned |
| 3 | firstboot-steps | **PASS** | access agent complete console images install ovf |
| 3a | console-onetime-printed | **PASS** | first boot printed a one-time console password on the VM console (ttyS0) |
| 3a | console-login | **PASS** | PAM login as culvert with the one-time password → forced change → sudo with the new password → root |
| 3a | password-changed | **PASS** | chage: no change pending after the forced change |
| 3 | culvert-status-setup-pending | **PASS** |   STATE:              services running — setup pending (create the first admin at https://10.0.2.15:9090) |
| 3 | image-identity | **PASS** | culvert runs sha256:ca27cf9a645431ed77255efa0897daabb63bbed9c6b4acd6ac574820422d186c |
| 3 | setup-token | **PASS** | 32 characters, from culvert-status via the authenticated console; identical to the token first boot printed on the VM console |
| 3c | operator-commands-refused | **PASS** | 'bash'→2 'status; id'→2 'sudo -n id'→2 '/bin/sh -c id'→2 'status-json --help'→2 'reboot'→2 |
| 3c | forwarding-refused | **PASS** | local-forward:refused remote-forward:255 stdio-forward:255 |
| 3c | file-transfer-refused | **PASS** | scp-legacy:1 scp-sftp:255 sftp:255 |
| 3c | local-admin-ssh-refused | **PASS** | culvert@ with the imported key: exit 255 |
| 3c | sshd-effective | **PASS** | AllowUsers culvert-operator, PasswordAuthentication no, DisableForwarding yes, ForceCommand culvert-access; operator has no sudo |
| 3c | local-admin-sudo-needs-password | **PASS** | culvert: sudo -n refused (a password is required) |
| 3d | boot-timing | **INFO** | Startup finished in 3.025s (kernel) + 46.608s (userspace) = 49.634s ; slowest: 39.802s culvert-firstboot.service 1.573s systemd-networkd-wait-online.service 1.437s cloud-init-local.service |
| 3e | recovery-secrets | **PASS** | root reveal shows both .env passphrases exactly, no setup token, with custody guidance; unprivileged invocation refused |
| 4a | bootstrap-api-needs-token | **PASS** | POST /api/auth/users 403, PUT default-auth-outcome 403 without the token; status-json still setup_status=pending |
| 4 | setup-without-token | **PASS** | 403 |
| 4 | setup-with-token | **PASS** | 200 |
| 4 | admin-login | **PASS** | 200 |
| 4 | status-setup-complete | **PASS** | culvert-status: setup complete |
| 4 | operator-setup-complete | **PASS** | status-json setup_status=completed, administrator_enrolled=True |
| 4b | demotion-immediate | **PASS** | labop admin session: GET /api/auth/users 200 → demoted to viewer → the same session 403 |
| 4b | portal-cookie-replay | **BLOCKED** | needs an identity provider (none in this lab); covered by TestUISessionRole_RejectsReplayedPortalCookie and the proxy cookie-boundary tests in CI |
| 5 | auth-exempt | **PASS** | 200 |
| 5 | default-deny | **PASS** | {"defaultAction":"deny"} |
| 5 | traffic | **PASS** | example.com 403 → rule → 200; example.org 403 (real egress through the guest proxy) |
| 5 | ready-rows | **PASS** | ca ok;policy_loaded ok;policy_posture ok; |
| 5 | clamav-real | **PASS** | /ready clamav ok — the REAL clamav/clamav sidecar from the OVA, signatures fetched by the guest |
| 5 | status-ready-to-enforce | **PASS** | culvert-status: ready to enforce |
| 5 | ca-identity | **PASS** | root CA sha256 88:E8:1C:82:66:D7:23:A8:DA:2A:1B:A0:6C:0D:E6:02:AD:AD:11:03:F0:94:E5:7C:EF:65:32:06:A0:76:B6:A2 |
| 5b | category-data | **PASS** | UT1 sync complete (lastSync entries: 2026-10-26T14:25:24Z 2600881); 2 of 5 probe hosts resolve via the community tier |
| 5c | category-enforcement | **PASS** | thepiratebay.org (Malicious via UT1): category rule → 403; without it → 301 |
| 6 | agent-installed | **PASS** | culvert-maint active, version v1.0.327-candidate.gb910508629e9 = proxy v1.0.327-candidate.gb910508629e9, no agent.pending |
| 6 | agent-reachable | **PASS** | agent v1.0.327-candidate.gb910508629e9 reachable over its socket, privilege_mode=sudoers, compose stack up |
| 6 | agent-backup | **PASS** | op 01M5W9RS807XZY406ZCEN1Z3Y5 → culvert-backup-20261026-142757-824077.tar.gz succeeded (proxy → agent socket → sudoers → cli container) |
| 6 | backup-listed | **PASS** | culvert-backup-20261026-142757-824077.tar.gz listed by /api/backups (available=true, one entry) |
| 6 | restore-dry-run | **PASS** | Validation: PASS; dry run, no files written (Culvert version: v1.0.327-candidate.gb910508629e9) |
| 6b | restore-refused-while-running | **PASS** | commit against the running stack refused (Restore commit error: restore: data directory is locked by another Culvert process (is the proxy still running? stop the stack first)); the post-backup rule is untouched |
| 6b | allowlist-survived-restore | **PASS** | admin marker allowlist-survives-marker.example present after restore (not re-added) — the saved allowlist survived the backup |
| 6b | restore-commit | **PASS** | down → restore --confirm → up: login 200, backup rules back (lab-allow-example), post-backup rule gone, example.com 200 / example.net 403 |
| 6c | test-only-trust | **PASS** | registry CA, hosts entry, fixture keyring (public) installed; agent restarted; running image sha256:ca27cf9a645431ed77255efa0897daabb63bbed9c6b4acd6ac574820422d186c now carries ghcr.io/kidcarmi/culvert@sha256:ca27cf9a645431ed77255efa0897daabb63bbed9c6b4acd6ac574820422d186c |
| 6c | unsigned-apply-refused | **PASS** | apply without release evidence: 403 ("error":"release trust: signed release proof required"); still running the baseline |
| 6c | signed-apply | **PASS** | agent apply with signed target + baseline evidence: succeeded; running sha256:b043d0e9abfc5d8fb0b85948d75b797d089869b8a4d5cd321a155ae1d89e034d (lab-target label); enforcement after the swap: example.com 200, example.org 403 |
| 6c | signed-rollback | **PASS** | agent image rollback to the signed baseline: succeeded; running sha256:ca27cf9a645431ed77255efa0897daabb63bbed9c6b4acd6ac574820422d186c again; example.com 200, example.org 403; admin login 200 |
| 6d | support-bundle | **PASS** | created csb_qbieum5c25t5zczvzcdtjt6wec (case lab-persist): 200, approved: 204 |
| 7 | os-update | **PASS** | culvert-os-update os exit 0 (0 package actions) |
| 7 | reboot | **PASS** | proxy /health and operator SSH back 31s after the reboot command |
| 7 | kernel | **INFO** | kernel unchanged (7.0.0-38-generic): no newer linux-image was installed |
| 7 | docker-held | **PASS** | Docker packages still held; engine 29.9.2 |
| 8 | stack-resumed | **PASS** | culvert-stack-resume.service took the os-update + agent locks, started the stack and cleared its marker |
| 8 | admin-login | **PASS** | 200 after reboot |
| 8 | policy-persisted | **PASS** | rules: lab-allow-example |
| 8 | enforcement | **PASS** | example.com 200, example.org 403 (also proves Exempt auth survived) |
| 8 | ready | **PASS** | /ready 200 |
| 8 | ca-identity | **PASS** | unchanged 88:E8:1C:82:66:D7:23:A8:DA:2A:1B:A0:6C:0D:E6:02:AD:AD:11:03:F0:94:E5:7C:EF:65:32:06:A0:76:B6:A2 |
| 8 | ca-encrypted-at-rest | **PASS** | /data/ca.bundle starts PSCA, no PEM private key, .env CULVERT_CA_PASSPHRASE non-empty |
| 8 | support-persisted | **PASS** | csb_qbieum5c25t5zczvzcdtjt6wec listed after the reboot: state=ready, case=lab-persist |
| 8 | category-data | **PASS** | category lookups identical before/after reboot |
| 8 | backup-listed | **PASS** | culvert-backup-20261026-142757-824077.tar.gz still listed (available=true, one entry) |
| 8 | agent-reachable | **PASS** | agent v1.0.327-candidate.gb910508629e9 reachable over its socket, privilege_mode=sudoers, compose stack up (after the maintenance reboot) |
| 8 | firstboot-not-rerun | **PASS** | no first-boot step ran on the second boot |
| 8 | state-files | **PASS** | first-boot state files unchanged |
| 8 | restore-persisted | **PASS** | the restored policy (no lab-post-backup) survived the reboot |
| 8 | image-identity | **PASS** | culvert runs sha256:ca27cf9a645431ed77255efa0897daabb63bbed9c6b4acd6ac574820422d186c after the reboot (the signed rollback target) |
| 8 | operator-status | **PASS** | status-json after the reboot: setup_status=completed, phase=ready |
| 8 | boot-timing | **INFO** | Startup finished in 3.078s (kernel) + 16.521s (userspace) = 19.599s ; slowest: 13.267s culvert-stack-resume.service 802ms docker.service 734ms apport.service |
| E | engine-version | **PASS** | docker-ce=5:29.9.2-1~ubuntu.24.04~noble containerd.io=2.4.2-3~ubuntu.24.04~noble docker-server-running=29.9.2 containerd-running=v2.4.2 dockerd-go=go1.26.10  |
| E | kernel-is-the-only-installed | **PASS** | running=7.0.0-38-generic |
| E | snapd-absent | **PASS** | package and state removed |
| E | engine-no-tcp-listener | **PASS** | dockerd/containerd/shim/runc: no TCP listener; docker-proxy only on published ports (8080 9090) |
| E | containerd-socket-root-only | **PASS** | root:root 0660 |
| E | docker-socket-root-only | **PASS** | root:docker 660, docker group has no members |
| E | dockerd-no-tcp-host | **PASS** | no tcp host in dockerd argv or daemon.json |
| E | containerd-cri-disabled | **PASS** | io.containerd.grpc.v1 cri (the CRI API) not loaded; disabled_plugins = ["cri"] |
| E | kernel-modules-denied | **PASS** | 67 denied modules (sctp, nfsd, kvm*, ksmbd, cifs, can*, pppoe, pppox, RDMA core, dccp, tipc, ip_vs, openvswitch, vxlan, LIO target, sound, Bluetooth, rxrpc/kafs, amdgpu, idpf, scsi_debug, the 21 network-autoloadable modules the GA disk did not carry, and the NVMe-oF target nvmet/nvmet_tcp): for each |
| E | kernel-hwe | **PASS** | running 7.0.0-38-generic = the one installed image; linux-image-virtual-hwe-24.04=7.0.0-38.38~24.04.4; no GA metapackage |
| E | drm-root-only | **PASS** | no DRM node exists: the shipped kernel cmdline carries nomodeset, so vmwgfx does not bind (module loaded: 0); 72-culvert-drm.rules (147c52f3a807) stays installed for a node that ever appears |
| E | kernel-cve-assumptions | **PASS** | unprivileged BPF disabled (2), perf_event_paranoid 4, 2 containers unprivileged with no added caps or devices, no perf tool, no FUSE/btrfs/NFS mounts, unprivileged userns restricted, ldisc autoload off, network autoload total=61 denied=29 reviewed=32 (none unreviewed); NICs: e1000  |
| E | ext4-no-ea-inode | **PASS** | 2 ext4 mount(s) without ea_inode: / /boot  |
| E | extra-modules-unloadable | **PASS** | extra-module nvmet_tcp files=1 rc=1 loaded-after=0 refused-by=nvmet extra-module ib_srpt files=1 rc=1 loaded-after=0 refused-by=ib_core  |
| E | containerd-tracing-off | **PASS** | no OTLP endpoint configured |
| R | io-accounting | **INFO** | LAB-ONLY guest change for attribution: systemd DefaultIOAccounting=yes (DefaultIOAccounting=yes) |
| R | clamav-evidence | **PASS** | a fresh EICAR body is answered '403 Blocked by CLAMAV scan' with clamd up, NOT with clamd stopped (403:Blocked: antivirus scanning is currently unavailable, so thi), and again after clamd restarts |
| R | variant-base | **INFO** | LAB-ONLY guest change set 'base' applied: base: no change  |
| R | readahead-base | **PASS** | effective read_ahead_kb=4096 == expected 4096 before measurement |
| R | profile-fast | **INFO** | disk: read +0ms, write +0ms per I/O (0 83886080 linear 7:0 0 ); budget 60s; 3 maintenance reboots |
| R | backup-list-fast-1 | **PASS** | first listing http 200: culvert-backup-20261026-142757-824077.tar.gz (11606 bytes, encrypted=False) in 0.634s, count=1 (login 0.111s, not counted) |
| R | operator-capture-integrity-fast-1 | **PASS** | 6 sanitized records, all complete and reparse (overflow=0 unparseable=0) |
| R | recovery-fast-1 | **PASS** | recovered in 36.9s (budget 60s; unrounded 36.85422600000004): kernel=+6.3s first_ready_clamav_ok=+26.3s first_traffic_allow_block=+26.4s first_eicar_blocked_by_clamav=+26.5s first_operator_phase_ready=+26.9s first_joint_sample=+26.9s third_consecutive_joint_sample=+36.9s; samples=6; host disk: 8767  |
| R | readahead-fast-1 | **PASS** | effective read_ahead_kb=4096 == expected 4096 (post-reboot, stack up) |
| R | state-fast-1 | **PASS** | admin login, normalized policy (persisted, not draft) + valid default action, CA, image and agent availability equal the pre-reboot baseline |
| R | backup-list-fast-2 | **PASS** | first listing http 200: culvert-backup-20261026-142757-824077.tar.gz (11606 bytes, encrypted=False) in 0.620s, count=1 (login 0.111s, not counted) |
| R | operator-capture-integrity-fast-2 | **PASS** | 7 sanitized records, all complete and reparse (overflow=0 unparseable=0) |
| R | recovery-fast-2 | **PASS** | recovered in 41.7s (budget 60s; unrounded 41.70773800000006): kernel=+6.3s first_ready_clamav_ok=+31.1s first_traffic_allow_block=+31.2s first_eicar_blocked_by_clamav=+31.3s first_operator_phase_ready=+31.7s first_joint_sample=+31.7s third_consecutive_joint_sample=+41.7s; samples=7; host disk: 8739  |
| R | readahead-fast-2 | **PASS** | effective read_ahead_kb=4096 == expected 4096 (post-reboot, stack up) |
| R | state-fast-2 | **PASS** | admin login, normalized policy (persisted, not draft) + valid default action, CA, image and agent availability equal the pre-reboot baseline |
| R | backup-list-fast-3 | **PASS** | first listing http 200: culvert-backup-20261026-142757-824077.tar.gz (11606 bytes, encrypted=False) in 0.621s, count=1 (login 0.110s, not counted) |
| R | operator-capture-integrity-fast-3 | **PASS** | 6 sanitized records, all complete and reparse (overflow=0 unparseable=0) |
| R | recovery-fast-3 | **PASS** | recovered in 36.6s (budget 60s; unrounded 36.609122999999954): kernel=+6.3s first_ready_clamav_ok=+26.0s first_traffic_allow_block=+26.2s first_eicar_blocked_by_clamav=+26.3s first_operator_phase_ready=+26.7s first_joint_sample=+26.7s third_consecutive_joint_sample=+36.6s; samples=6; host disk: 8722 |
| R | readahead-fast-3 | **PASS** | effective read_ahead_kb=4096 == expected 4096 (post-reboot, stack up) |
| R | state-fast-3 | **PASS** | admin login, normalized policy (persisted, not draft) + valid default action, CA, image and agent availability equal the pre-reboot baseline |
| R | recovery-cases | **PASS** | 3 of 3 profile x reboot cases ran |
| H | history-recorded | **PASS** | 12 marker requests (hist9766fbe85fdc-*) in the history store |
| H | history-export | **PASS** | POST /api/logs/history/export → 3445 bytes, encrypted stream (CVRTST01), sha256 0c45ec3f5b2cb938…, held on the runner |
| H | history-export-opaque | **PASS** | no marker host is readable in the archive bytes |
| H | history-backup | **PASS** | culvert-backup-20261026-144354-146699.tar.gz |
| H | history-source-destroyed | **PASS** | data volume deleted (volume=culvert_proxy-data), restored from culvert-backup-20261026-144354-146699.tar.gz into a fresh volume, CULVERT_LOG_PASSPHRASE rotated |
| H | history-gone-after-restore | **PASS** | after the restore the history store is ON (new key) and holds 0 marker records — the backup does not carry history |
| H | history-import-refused-while-running | **PASS** | refused against the running proxy: History import error: data directory is locked by another Culvert process (is the proxy still running? stop the stack first) |
| H | history-wrong-passphrase | **PASS** | wrong archive passphrase refused (backup decrypt failed (invalid passphrase or tampered backup)), nothing imported |
| H | history-import-dry-run | **PASS** | history archive OK: 12 records, 0 skipped at export, created 2026-10-26T14:43:53Z |
| H | history-recovered | **PASS** | imported=12 duplicate=0 rekeyed=0 expired=0 invalid=0; the 12 marker records read back identical (ts, host, status, method) under the ROTATED log key |
| H | allowlist-survived-recovery | **PASS** | admin marker allowlist-survives-marker.example present after fresh-volume recovery (not re-added) |
| H | history-enforcement | **PASS** | example.com 200 through the proxy after the recovery |
| P | host-bound | **PASS** | host free 76 GiB; disk file allocated 6183 MiB; caps: growth <= 3072 MiB, abort below 5 GiB free |
| P | clamav-baseline | **PASS** | a fresh EICAR draws the ClamAV block before any fill |
| P | pkgfix-setup | **PASS** | culvert-lab-pkgfix 1.0 installed, 2.0 offered (64 MiB blob + 3000 files) from a local file: repository |
| P | blocks-filled | **INFO** | filled bytes=36412538880 free_root=16777216 free_user=0  host disk file +262 MiB |
| P | blocks-enforcement | **PASS** | blocked 403 throughout, EICAR never delivered (9 samples; eicar/clean: 403/403 x2, av/200 x2, av/403 x5); admin login 200 |
| P | blocks-readiness-truth | **PASS** | 6 sample(s) refused content as AV-unavailable; /ready was non-200 with the clamav row failing in every one |
| P | blocks-backup-clean | **INFO** | op=01M5WAWERV70WF5KQRQVFY8FAN state=succeeded http=200: the backup SUCCEEDED under pressure and the new archive is complete (newest=culvert-backup-20261026-144726-746764.tar.gz archive=valid ); every existing archive byte-identical |
| P | blocks-app-update | **PASS** | failed with nothing changed: op-state=failed (preflight_space); running-image=sha256:ca27cf9a645431ed77255efa0897daabb63bbed9c6b4acd6ac574820422d186c; traffic 200/403 |
| P | blocks-os-update | **INFO** | osu-rc=100; dpkg left INTERRUPTED (dpkg-journal=5 journal entries; apt refuses until dpkg --configure -a) — the repair is judged by blocks-pkg-recovered; Docker still held, traffic 200/403 |
| P | blocks-pkg-write | **INFO** | dpkg wrote part of 2.0, failed (osu-rc=100) and could not record it: left INTERRUPTED (dpkg-journal=5 journal entries); fixture=[install ok installed 1.0]; repair judged by blocks-pkg-recovered |
| P | blocks-recovered | **PASS** | space released; /ready 200 with clamav ok, enforcement, EICAR blocked by ClamAV (200 403 av 200 200 200); held: containerd.io docker-ce docker-ce-cli docker-compose-plugin  |
| P | blocks-pkg-recovered | **PASS** | space back: culvert-os-update os rc=0, culvert-lab-pkgfix now 2.0, dpkg audit empty |
| P | blocks-backup-after | **PASS** | op=01M5WAY9VRRKN3F6Y5G4CJT40Q state=succeeded http=200; newest=culvert-backup-20261026-144827-255935.tar.gz archive=valid  (gzip tar readable end to end); admin login 200 |
| P | blocks-no-crash | **PASS** | proxy restart count and start time unchanged across the phase (0 2026-10-26T14:44:43.01722893Z) |
| P | inodes-filled | **INFO** | files=5049443 free_inodes=0 free_blocks_bytes=36291211264 secs=184  host disk file +733 MiB |
| P | inodes-enforcement | **PASS** | blocked 403 throughout, EICAR never delivered (9 samples; eicar/clean: 403/403 x9); admin login 200 |
| P | inodes-readiness-truth | **PASS** | 8 sample(s) refused content as AV-unavailable; /ready was non-200 with the clamav row failing in every one |
| P | inodes-backup-clean | **PASS** | op=none state=none http=502; no new archive, no .tmp, 5 existing archive(s) byte-identical |
| P | inodes-app-update | **PASS** | failed with nothing changed: op-state=failed ("error":"open_op_log_failed); running-image=sha256:ca27cf9a645431ed77255efa0897daabb63bbed9c6b4acd6ac574820422d186c; traffic 403/403 |
| P | inodes-os-update | **PASS** | osu-rc=100; dpkg consistent (audit empty, journal empty, no half-installed package), Docker still held, traffic 403/403 |
| P | inodes-pkg-write | **INFO** | dpkg never reached the package (osu-rc=100; apt stopped first: W: Symlinking file /var/lib/culvert-lab-pkgfix/repo/./Packages to /var/lib/apt/lists/partial/_var_lib_culvert-lab-pkgfix_repo_._Packages failed - pkgAcqIndex::S); fixture=[install ok installed 1.0] |
| P | inodes-recovered | **PASS** | space released; /ready 200 with clamav ok, enforcement, EICAR blocked by ClamAV (200 403 av 200 200 200); held: containerd.io docker-ce docker-ce-cli docker-compose-plugin  |
| P | inodes-pkg-recovered | **PASS** | space back: culvert-os-update os rc=0, culvert-lab-pkgfix now 2.0, dpkg audit empty |
| P | inodes-backup-after | **PASS** | op=01M5WBDS78E1GBAQEHANHSPHRC state=succeeded http=200; newest=culvert-backup-20261026-145654-504392.tar.gz archive=valid  (gzip tar readable end to end); admin login 200 |
| P | inodes-no-crash | **PASS** | proxy restart count and start time unchanged across the phase (0 2026-10-26T14:44:43.01722893Z) |
| P | pkgblocks-filled | **INFO** | filled headroom_target=25165824 free_root=25149440 free_user=8372224  host disk file +817 MiB |
| P | pkgblocks-enforcement | **PASS** | blocked 403 throughout, EICAR never delivered (9 samples; eicar/clean: av/200 x9); admin login 200 |
| P | pkgblocks-readiness-truth | **INFO** | no sample refused content as AV-unavailable |
| P | pkgblocks-backup-clean | **INFO** | op=01M5WBJENF19AC3ZBX62EQ4RYF state=succeeded http=200: the backup SUCCEEDED under pressure and the new archive is complete (newest=culvert-backup-20261026-145927-535223.tar.gz archive=valid ); every existing archive byte-identical |
| P | pkgblocks-app-update | **INFO** | not exercised in this phase (the blocks and inodes phases cover it); this phase targets the package write |
| P | pkgblocks-os-update | **PASS** | osu-rc=100; dpkg consistent (audit empty, journal empty, no half-installed package), Docker still held, traffic 200/403 |
| P | pkgblocks-pkg-write | **PASS** | dpkg started writing 2.0 and failed (osu-rc=100: dpkg: error processing archive /var/lib/culvert-lab-pkgfix/repo/./culvert-lab-pkgfix_2.0_all.deb (--unpack):); rolled back to 1.0 fully installed, dpkg audit empty |
| P | pkgblocks-recovered | **PASS** | space released; /ready 200 with clamav ok, enforcement, EICAR blocked by ClamAV (200 403 av 200 200 200); held: containerd.io docker-ce docker-ce-cli docker-compose-plugin  |
| P | pkgblocks-pkg-recovered | **PASS** | space back: culvert-os-update os rc=0, culvert-lab-pkgfix now 2.0, dpkg audit empty |
| P | pkgblocks-backup-after | **PASS** | op=01M5WBKKP7EE48TAX24YWXGX5T state=succeeded http=200; newest=culvert-backup-20261026-150005-447133.tar.gz archive=valid  (gzip tar readable end to end); admin login 200 |
| P | pkgblocks-no-crash | **PASS** | proxy restart count and start time unchanged across the phase (0 2026-10-26T14:44:43.01722893Z) |
| P | pkginodes-filled | **INFO** | files=5049415 headroom_target=400 free_inodes=0 free_blocks_bytes=36264206336  host disk file +862 MiB |
| P | pkginodes-enforcement | **PASS** | blocked 403 throughout, EICAR never delivered (9 samples; eicar/clean: 403/403 x9); admin login 200 |
| P | pkginodes-readiness-truth | **PASS** | 8 sample(s) refused content as AV-unavailable; /ready was non-200 with the clamav row failing in every one |
| P | pkginodes-backup-clean | **PASS** | op=none state=none http=502; no new archive, no .tmp, 8 existing archive(s) byte-identical |
| P | pkginodes-app-update | **INFO** | not exercised in this phase (the blocks and inodes phases cover it); this phase targets the package write |
| P | pkginodes-os-update | **PASS** | osu-rc=100; dpkg consistent (audit empty, journal empty, no half-installed package), Docker still held, traffic 403/403 |
| P | pkginodes-pkg-write | **PASS** | dpkg started writing 2.0 and failed (osu-rc=100: dpkg: error processing archive /var/lib/culvert-lab-pkgfix/repo/./culvert-lab-pkgfix_2.0_all.deb (--unpack):); rolled back to 1.0 fully installed, dpkg audit empty |
| P | pkginodes-recovered | **PASS** | space released; /ready 200 with clamav ok, enforcement, EICAR blocked by ClamAV (200 403 av 200 200 200); held: containerd.io docker-ce docker-ce-cli docker-compose-plugin  |
| P | pkginodes-pkg-recovered | **PASS** | space back: culvert-os-update os rc=0, culvert-lab-pkgfix now 2.0, dpkg audit empty |
| P | pkginodes-backup-after | **PASS** | op=01M5WC31WKQ9AN84RY57WDT8WJ state=succeeded http=200; newest=culvert-backup-20261026-150831-506203.tar.gz archive=valid  (gzip tar readable end to end); admin login 200 |
| P | pkginodes-no-crash | **PASS** | proxy restart count and start time unchanged across the phase (0 2026-10-26T14:44:43.01722893Z) |
| P | pkgfix-teardown | **PASS** | fixture package, source and repository removed from the disposable guest |

Totals: blocked=1, info=18, pass=157

Not qualified by this lab: vSphere/ESXi import (ovftool), the guestinfo OVF transport, VMware Tools, LSI Logic SCSI, the hypervisor's tty1 console (ttyS0 here), datastore/thin-provisioning behaviour, the proxy's Release Management dispatch (6c calls the agent socket as its peer, with TEST-ONLY trust), and F-DISK-1 (owned by the bounded nested-Docker harness; still OPEN).
