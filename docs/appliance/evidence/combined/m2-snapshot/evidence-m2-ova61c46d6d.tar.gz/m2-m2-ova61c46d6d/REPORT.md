# Appliance lab — guest boot qualification (run 20261027T082323Z)

| identity | value |
|---|---|
| lab/harness commit | `0071fc13b60a37b157ed9c9d5fff13a31967b60a` |
| OVA | `culvert-appliance-1.0.327-candidate.gb910508629e9-ubuntu-24.04.ova` sha256 `61c46d6db6603d76edbb0d64327bed85e76bea86d24457e9f3ae36e71bd5854a` |
| appliance source (guest build-info) | `?` |
| application image in the guest | `?` |
| accelerator | kvm (preflight: `preflight.json`) |
| access | read-only `culvert-operator` SSH (imported key) + authenticated local console (`culvert`, PAM + sudo) |

| step | check | result | detail |
|---|---|---|---|
| P | tools | **PASS** | qemu, qemu-img, ssh, curl, python3, openssl, iso tool present |
| P | memory | **PASS** | 14631 MiB available (need 6144) |
| P | disk | **PASS** | 82 GiB free at //culvert-lab/lab (need 20: OVA + VMDK + base + overlay growth) |
| P | accel | **PASS** | accel=kvm (kvm usable: yes) |
| 1 | ova-sha256 | **PASS** | culvert-appliance-1.0.327-candidate.gb910508629e9-ubuntu-24.04.ova sha256 61c46d6db6603d76edbb0d64327bed85e76bea86d24457e9f3ae36e71bd5854a |
| 1 | ova-manifest | **PASS** | every .mf digest matches |
| 1 | disk-chain | **PASS** | base.qcow2 (0444, from the OVA's own VMDK) ← overlay.qcow2 (disposable) |
| 2 | boot-started | **PASS** | qemu pid 8330 accel=kvm |
| 2 | kernel-started | **PASS** | [    0.000000] Linux version 7.0.0-38-generic (buildd@lcy02-amd64-063) (x86_64-linux-gnu-g after 5s |
| 2 | operator-ssh-up | **PASS** | culvert-operator SSH (OVF-delivered key, status-json) after 23s |
| 2 | firstboot-complete | **PASS** | status-json: complete recorded, phase provisioned, 55s from power-on |
| M2 | snapshot | **PASS** | boot_id=01e9f070-c5e0-405d-8aeb-927319d80a07; build-git-commit="git_commit": "b910508629e9d80352067bc8ec608753ddf0924e"; 72 modules loaded |
| M2 | snapshot-loaded-nothing | **PASS** | the loaded-module set is identical before and after the snapshot |
| M2 | fou-gue | **INFO** | fou not loaded: no FOU/GUE receive port can exist |
| M2 | stmmac | **INFO** | any stmmac/dwmac bound: ; NIC net ens4 driver=e1000 type=1 flags=0x1003  |
| M2 | nvmet | **INFO** | nvmet modules loaded: ; /sys/kernel/config/nvmet absent; nvme listener ports (4420 0x1144 / 8009 0x1F49) in the root ns tcp table: 0 |
| M2 | namespaces | **INFO** | 3 network namespace(s) observed |

Totals: info=4, pass=13

Not qualified by this lab: vSphere/ESXi import (ovftool), the guestinfo OVF transport, VMware Tools, LSI Logic SCSI, the hypervisor's tty1 console (ttyS0 here), datastore/thin-provisioning behaviour, the proxy's Release Management dispatch (6c calls the agent socket as its peer, with TEST-ONLY trust), and F-DISK-1 (owned by the bounded nested-Docker harness; still OPEN).
