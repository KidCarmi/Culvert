# Disk exhaustion during an active database write (F-DISK-1) — run 20261025T103330Z

| artifact | reference |
|---|---|
| image under qualification | `culvert:ci-smoke` → `172.17.0.1:5056/culvert@sha256:7aef494381724759485a2c334beb723390b91d850a3b453e0c23a85ad3921556` |
| predecessor | `culvert:ci-smoke` → `172.17.0.1:5056/culvert@sha256:7aef494381724759485a2c334beb723390b91d850a3b453e0c23a85ad3921556` |
| bounded host | `docker:29-dind@sha256:7dcdfc4a20246236f558175182ccace1eb15a41bd3eb119dd2284f393498b7c1`, data root + containerd + stack + agent state on one 2048 MiB ext4 loop file (-m 0) |
| agent | shipped binary sha256 81e4214d98f3cf9b1fffc3e41a2e5576f643c9865e7a49f908d700fd105ce64e, v1.0.327-candidate.gb910508629e9, privilege_mode=docker_group_lab, inside the bounded host |

| scenario | check | result | detail |
|---|---|---|---|
| E0 | bounded-fs | **PASS** | size=1992552KiB avail=1976120KiB image=/home/runner/work/_temp/fdisk1/attempt-1/appliance-root.img (sparse, cap 2048MiB) |
| E0 | image-content-cur | **PASS** | pushed 172.17.0.1:5056/culvert@sha256:7aef494381724759485a2c334beb723390b91d850a3b453e0c23a85ad3921556 has config sha256:75dd735cebbfe312e7f15c2e86f82bf66493853d707c6d2b3d664e03f6e47779 (re-hashed) = source tar config; tar sha256 1db620abbf4fe34424749e64a4e8b9 |
| E0 | image-content-pred | **PASS** | pushed 172.17.0.1:5056/culvert@sha256:7aef494381724759485a2c334beb723390b91d850a3b453e0c23a85ad3921556 has config sha256:75dd735cebbfe312e7f15c2e86f82bf66493853d707c6d2b3d664e03f6e47779 (re-hashed) = source tar config; tar sha256 1db620abbf4fe34424749e64a4e8b9 |
| E0 | image-store-bounded | **PASS** | server=29.8.2 driver=overlayfs root=/var/lib/docker containerd-store=[[driver-type io.containerd.snapshotter.v1]]; content store /var/lib/docker/containerd/daemon/io.containerd.content.v1.content; every state dir on one device (1792 ) |
| E0 | dind-image | **PASS** | docker:29-dind@sha256:7dcdfc4a20246236f558175182ccace1eb15a41bd3eb119dd2284f393498b7c1 = docker@sha256:7dcdfc4a20246236f558175182ccace1eb15a41bd3eb119dd2284f393498b7c1 |
| E0 | image-pulled | **PASS** | nested daemon runs sha256:7aef494381724759485a2c334beb723390b91d850a3b453e0c23a85ad3921556 = the pushed manifest digest |
| E0 | seeded-predecessor | **PASS** | running v1.0.327-candidate.gb910508629e9 image=sha256:7aef494381724759485a2c334beb723390b91d850a3b453e0c23a85ad3921556 state=d544a26ee2aee034 |
| E0 | image-running | **PASS** | container culvert runs sha256:7aef494381724759485a2c334beb723390b91d850a3b453e0c23a85ad3921556 |
| E0 | ca-identity | **PASS** | root CA sha256 D1:7F:28:65:6F:51:3C:4C:80:6E:05:F0:9B:0C:50:B9:44:3C:04:C1:53:B8:A8:CE:44:DC:95:51:5A:34:7E:12 |
| E0 | enforcement | **PASS** | allowed=200 blocked=403 with the default-deny block page (real traffic through the proxy) |
| E0 | agent-identity | **PASS** | shipped binary sha256 81e4214d98f3cf9b1fffc3e41a2e5576f643c9865e7a49f908d700fd105ce64e, v1.0.327-candidate.gb910508629e9 |
| E0 | agent-start | **PASS** | {"agent_version":"v1.0.327-candidate.gb910508629e9","status":"ok"} |
| W | write-in-flight | **INCONCLUSIVE** | the write finished while the fill was being placed; nothing was tested |

Failures: 0
